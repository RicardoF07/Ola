<?php

require_once 'vendor/autoload.php';
use thiagoalessio\TesseractOCR\TesseractOCR;

function logMessage($message) {
    file_put_contents('log.txt', date('Y-m-d H:i:s') . " - " . $message . "\n", FILE_APPEND);
}

header('Content-Type: application/json; charset=UTF-8');

logMessage('Pedido Recebido');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (!isset($_POST['base_img'])) {
        logMessage('Sem dados de imagem recebidos');
        echo json_encode(["error" => "Nenhum dado de imagem recebido"]);
        exit;
    }

    logMessage('Dado de Imagem recebido');
    $data = str_replace(" ", "+", $_POST['base_img']);
    $nome = md5(time() . uniqid());
    $path = "snaps/{$nome}.jpg";

    $data = explode(',', $data);
    if (count($data) != 2) {
        logMessage('Dado de Imagem mal formado');
        echo json_encode(["error" => "Falha no data da imagem."]);
        exit;
    }

    if (!file_put_contents($path, base64_decode(trim($data[1])))) {
        logMessage('Falha ao guardar a imagem');
        echo json_encode(["error" => "Falha ao guardar a imagem."]);
        exit;
    }

    logMessage('Imagem guardada com sucesso');
    try {
        $fileRead = (new TesseractOCR($path))
            ->lang('por') 
            ->run();

        logMessage('OCR success: ' . $fileRead);
        echo json_encode(["text" => $fileRead]);
        exit;
    } catch (Exception $e) {
        logMessage('OCR error: ' . $e->getMessage());
        echo json_encode(["error" => $e->getMessage()]);
        exit;
    }
} 